# APK GAME STORE — ការដំឡើង

## មុខងារ
- គេហទំព័របង្ហាញហ្គេម និងស្វែងរកតាមឈ្មោះ
- Admin Login និងបញ្ចូល APK (.apk) ពីទូរស័ព្ទ ឬកុំព្យូទ័រ
- កំណត់ប្រភេទ Version ការពិពណ៌នា និងរូបភាព
- រាប់ចំនួនទាញយក និងលុបហ្គេម
- កន្លែងដាក់ Google AdSense (ត្រូវបញ្ចូលកូដពិតក្រោយពេលបានអនុម័ត)

## ដំណើរការលើកុំព្យូទ័រ
1. ត្រូវមាន Node.js 18 ឬថ្មីជាងនេះ។
2. ពន្លា ZIP ហើយបើក Terminal នៅក្នុង folder។
3. ដំណើរការ `npm install`
4. កំណត់ Environment Variables តាម `.env.example` (កុំប្រើពាក្យសម្ងាត់គំរូ)។
5. ដំណើរការ `npm start`
6. បើក `http://localhost:3000`

## Admin
URL: `/admin.html`
លំនាំដើមសម្រាប់សាកល្បងប៉ុណ្ណោះ៖
- Username: `admin`
- Password: `ChangeMe123!`

**សំខាន់៖** មុនបើកវេបសាយជាសាធារណៈ ត្រូវកំណត់ `ADMIN_USER`, `ADMIN_PASSWORD` និង `SESSION_SECRET` ជាតម្លៃផ្ទាល់ខ្លួនខ្លាំងៗក្នុង Hosting Environment Variables។ ត្រូវប្រើ HTTPS។

## ដាក់ Hosting
ប្រើ Hosting ដែលគាំទ្រ Node.js (ឧ. VPS ឬសេវា Node.js app hosting)។ Build command: `npm install`; Start command: `npm start`។ ត្រូវជ្រើស Persistent Disk/Volume សម្រាប់ folder `uploads/` និង `data/` ព្រោះ APK និងទិន្នន័យត្រូវរក្សាទុក។ Static hosting ដូចជា GitHub Pages មិនអាចដំណើរការ Admin upload/API របស់គម្រោងនេះបានទេ។

## ដាក់ពាណិជ្ជកម្ម និងរកចំណូល
1. បង្កើតគណនី Google AdSense និងបន្ថែម domain របស់អ្នក។
2. បង្កើត Ad Unit ហើយរង់ចាំ Google ពិនិត្យ/អនុម័តវេបសាយ។
3. បញ្ចូលកូដ AdSense ដែល Google ផ្ដល់ឱ្យក្នុង `public/index.html` នៅកន្លែង `AD SLOT` និងកែ `ads.txt` ប្រសិនបើ Google ស្នើ។
4. ចំណូលមិនធានាទេ។ វាអាស្រ័យលើការអនុម័ត ចំនួនអ្នកចូលមើល ប្រទេសអ្នកមើល និងការអនុលោមតាមគោលការណ៍ពាណិជ្ជកម្ម។

## សុវត្ថិភាព និងសិទ្ធិ
- បង្ហោះតែ APK ដែលអ្នកបង្កើត ឬមានសិទ្ធិចែកចាយ។ កុំបង្ហោះហ្គេមលួចចម្លង ឬ mod APK ដែលរំលោភសិទ្ធិ។
- ស្កេនឯកសារមុនបង្ហោះ និងបង្ហាញប្រភព/កំណែឱ្យច្បាស់។
- កំណត់ទំហំឯកសារតាមសមត្ថភាព Hosting; លំនាំដើមអនុញ្ញាតអតិបរមា 300MB។
- សម្រាប់ប្រើប្រាស់ធំ គួរបន្ថែម database, object storage, backup, rate limiting និងការត្រួតពិនិត្យ APK។
- កុំប្រើចរាចរណ៍ក្លែងក្លាយ ឬចុចលើពាណិជ្ជកម្មខ្លួនឯង។ អនុវត្តតាមគោលការណ៍ AdSense។

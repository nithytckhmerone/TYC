const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const DATA = path.join(__dirname, 'data');
const UPLOADS = path.join(__dirname, 'uploads');
[DATA, UPLOADS].forEach(p => { if (!fs.existsSync(p)) fs.mkdirSync(p, {recursive:true}); });
const DB = path.join(DATA, 'games.json');
if (!fs.existsSync(DB)) fs.writeFileSync(DB, '[]');
const readGames = () => JSON.parse(fs.readFileSync(DB, 'utf8'));
const saveGames = g => fs.writeFileSync(DB, JSON.stringify(g, null, 2));

app.use(express.json({limit:'1mb'}));
app.use(session({secret:SESSION_SECRET, resave:false, saveUninitialized:false, cookie:{httpOnly:true, sameSite:'lax', secure:process.env.NODE_ENV==='production', maxAge: 8*60*60*1000}}));
app.use('/uploads', express.static(UPLOADS));
app.use(express.static(path.join(__dirname, 'public')));
const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, UPLOADS),
  filename: (_, file, cb) => cb(null, Date.now()+'-'+crypto.randomBytes(5).toString('hex')+path.extname(file.originalname).toLowerCase())
});
const upload = multer({storage, limits:{fileSize:300*1024*1024}, fileFilter:(_, file, cb) => {
  if (path.extname(file.originalname).toLowerCase() !== '.apk') return cb(new Error('Only .apk files are allowed'));
  cb(null,true);
}});
const admin = (req,res,next) => req.session.admin ? next() : res.status(401).json({error:'សូមចូល Admin ជាមុនសិន'});
app.get('/api/games', (_,res) => res.json(readGames().filter(g=>g.published)));
app.post('/api/login', (req,res) => {
  const {username,password}=req.body||{};
  if(username===ADMIN_USER && password===ADMIN_PASSWORD){req.session.admin=true; return res.json({ok:true});}
  res.status(401).json({error:'ឈ្មោះអ្នកប្រើ ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវ'});
});
app.post('/api/logout', (req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/admin/games', admin, (_,res)=>res.json(readGames()));
app.post('/api/admin/games', admin, upload.single('apk'), (req,res)=>{
  const {name,category,version,description,image}=req.body;
  if(!name || !req.file) return res.status(400).json({error:'ត្រូវបញ្ចូលឈ្មោះហ្គេម និងឯកសារ APK'});
  const games=readGames();
  const game={id:crypto.randomUUID(),name:name.trim(),category:category||'ហ្គេម',version:version||'1.0',description:description||'',image:image||'',file:'/uploads/'+req.file.filename,size:req.file.size,downloads:0,published:true,createdAt:new Date().toISOString()};
  games.unshift(game); saveGames(games); res.json(game);
});
app.delete('/api/admin/games/:id', admin, (req,res)=>{
  const games=readGames(), game=games.find(g=>g.id===req.params.id);
  if(!game) return res.status(404).json({error:'រកមិនឃើញ'});
  if(game.file){const p=path.join(__dirname, game.file.replace(/^\\//,'')); if(fs.existsSync(p)) fs.unlinkSync(p);}
  saveGames(games.filter(g=>g.id!==req.params.id)); res.json({ok:true});
});
app.get('/download/:id', (req,res)=>{
  const game=readGames().find(g=>g.id===req.params.id && g.published);
  if(!game) return res.status(404).send('រកមិនឃើញឯកសារ');
  game.downloads=(game.downloads||0)+1; saveGames(readGames().map(g=>g.id===game.id?game:g));
  res.download(path.join(__dirname,game.file.replace(/^\\//,'')), path.basename(game.file));
});
app.use((err,req,res,next)=>res.status(400).json({error:err.message||'មានបញ្ហា'}));
app.listen(PORT,()=>console.log(`APK Game Store running on ${PORT}`));

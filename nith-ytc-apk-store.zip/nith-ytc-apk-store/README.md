# Nith YTC APK Store

A dark, responsive, public APK-sharing website built with Cloudflare Workers, R2 object storage, and D1 database.

## Features

- Public APK uploads and downloads
- App name, version, and description
- Searchable latest-upload list
- Download counters
- 50 MB upload limit
- Basic per-IP upload rate limit (5 uploads/hour by default)
- APK extension and ZIP-signature checks
- Responsive dark UI

## Important safety notes

This is a public file-sharing service. The ZIP signature check only confirms that the file resembles a ZIP archive; it does **not** verify Android package integrity or detect malware. Uploaded apps are immediately public. Do not host copyrighted, stolen, deceptive, or harmful apps. Consider adding Cloudflare Turnstile, moderation/approval, abuse reporting, and automated malware scanning before opening the site to large-scale public traffic.

The included IP rate limit is a basic deterrent, not a complete anti-abuse system. It stores a one-way SHA-256 hash of the connecting IP for up to one hour.

## Free-tier notes (not unlimited)

Cloudflare's published free allowances currently include R2 Standard storage of 10 GB-month, 1 million Class A operations and 10 million Class B operations per month, with no R2 egress fees. Workers Free includes 100,000 requests/day. Limits and pricing can change; monitor usage and configure billing/spending safeguards in your account. The app itself limits each upload to 50 MB.

## Deploy

You need a Cloudflare account and Node.js installed on a computer.

1. Install dependencies:

   ```bash
   npm install
   ```

2. Log in:

   ```bash
   npx wrangler login
   ```

3. Create the R2 bucket:

   ```bash
   npx wrangler r2 bucket create nith-ytc-apks
   ```

4. Create the D1 database:

   ```bash
   npx wrangler d1 create nith-ytc-apk-db
   ```

   Copy the returned database ID into `wrangler.toml`, replacing `REPLACE_WITH_D1_DATABASE_ID`.

5. Apply the database migration:

   ```bash
   npx wrangler d1 migrations apply nith-ytc-apk-db --remote
   ```

6. Deploy:

   ```bash
   npm run deploy
   ```

7. Open the `*.workers.dev` URL printed by Wrangler.

## Local development

After creating the R2 bucket and D1 database and updating `wrangler.toml`:

```bash
npm run dev
```

For local D1 migrations, run:

```bash
npx wrangler d1 migrations apply nith-ytc-apk-db --local
```

## Configuration

`wrangler.toml` has these defaults:

- `MAX_UPLOAD_MB = "50"` (application cap; do not exceed Cloudflare request body limits)
- `UPLOADS_PER_HOUR = "5"`

Change these values carefully. Cloudflare Free request body limits and Workers execution limits apply independently.

## API

- `GET /api/apps?q=search-term` — list/search public apps
- `POST /api/upload` — multipart form with `name`, `version`, `description`, and `apk`
- `GET /api/download/:uuid` — download APK and increment counter

## Project layout

```text
public/index.html       Frontend
src/index.js            Worker API
migrations/0001_init.sql D1 schema
wrangler.toml            Cloudflare bindings and settings
```

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
});

function safeName(value, fallback = "Android App") {
  return String(value || fallback).replace(/[<>\"'`]/g, "").trim().slice(0, 70) || fallback;
}

async function hashIp(ip) {
  const bytes = new TextEncoder().encode(ip || "unknown");
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, "0")).join("");
}

async function handleApi(request, env, url) {
  if (request.method === "GET" && url.pathname === "/api/apps") {
    const q = (url.searchParams.get("q") || "").trim().slice(0, 80);
    const result = q
      ? await env.DB.prepare(
          "SELECT id,name,description,version,file_name,file_size,downloads,created_at FROM apps WHERE name LIKE ? OR description LIKE ? ORDER BY created_at DESC LIMIT 100"
        ).bind(`%${q}%`, `%${q}%`).all()
      : await env.DB.prepare(
          "SELECT id,name,description,version,file_name,file_size,downloads,created_at FROM apps ORDER BY created_at DESC LIMIT 100"
        ).all();
    return json({ apps: result.results || [] });
  }

  if (request.method === "POST" && url.pathname === "/api/upload") {
    const maxBytes = Math.min(Number(env.MAX_UPLOAD_MB || 50), 50) * 1024 * 1024;
    const ipHash = await hashIp(request.headers.get("CF-Connecting-IP") || "unknown");
    const now = Math.floor(Date.now() / 1000);
    await env.DB.prepare("DELETE FROM upload_limits WHERE created_at < ?").bind(now - 3600).run();
    const count = await env.DB.prepare(
      "SELECT COUNT(*) AS n FROM upload_limits WHERE ip_hash = ? AND created_at > ?"
    ).bind(ipHash, now - 3600).first();

    if ((count?.n || 0) >= Number(env.UPLOADS_PER_HOUR || 5)) {
      return json({ error: "Upload limit reached. Please try again later." }, 429);
    }

    let form;
    try { form = await request.formData(); }
    catch { return json({ error: "Invalid upload form." }, 400); }

    const file = form.get("apk");
    if (!(file instanceof File) || !file.size) return json({ error: "Choose an APK file." }, 400);
    if (file.size > maxBytes) return json({ error: `APK is too large. Maximum size is ${Math.floor(maxBytes / 1024 / 1024)} MB.` }, 413);
    if (!file.name.toLowerCase().endsWith(".apk")) return json({ error: "Only .apk files are accepted." }, 400);

    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    // APK packages are ZIP archives. This checks the ZIP signature, not whether the APK is safe.
    const zip = bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b &&
      ([0x03, 0x05, 0x07].includes(bytes[2]) && [0x04, 0x06, 0x08].includes(bytes[3]));
    if (!zip) return json({ error: "The file does not look like a valid APK/ZIP package." }, 400);

    const id = crypto.randomUUID();
    const key = `${id}.apk`;
    const name = safeName(form.get("name"), file.name.replace(/\.apk$/i, ""));
    const description = String(form.get("description") || "").replace(/[<>]/g, "").trim().slice(0, 500);
    const version = safeName(form.get("version"), "1.0").slice(0, 30);
    const createdAt = new Date().toISOString();

    await env.APK_BUCKET.put(key, buffer, {
      httpMetadata: {
        contentType: "application/vnd.android.package-archive",
        contentDisposition: `attachment; filename="${id}.apk"`
      },
      customMetadata: { originalName: file.name.slice(0, 120) }
    });

    try {
      await env.DB.prepare(
        "INSERT INTO apps (id,name,description,version,file_name,object_key,file_size,created_at) VALUES (?,?,?,?,?,?,?,?)"
      ).bind(id, name, description, version, file.name.slice(0, 120), key, file.size, createdAt).run();
      await env.DB.prepare("INSERT INTO upload_limits (ip_hash,created_at) VALUES (?,?)").bind(ipHash, now).run();
    } catch (e) {
      await env.APK_BUCKET.delete(key);
      throw e;
    }
    return json({ ok: true, id, message: "Upload complete. Your APK is now listed." }, 201);
  }

  const downloadMatch = url.pathname.match(/^\/api\/download\/([a-f0-9-]{36})$/i);
  if (request.method === "GET" && downloadMatch) {
    const app = await env.DB.prepare(
      "SELECT id,name,object_key FROM apps WHERE id = ?"
    ).bind(downloadMatch[1]).first();
    if (!app) return json({ error: "APK not found." }, 404);
    const object = await env.APK_BUCKET.get(app.object_key);
    if (!object) return json({ error: "APK file is missing." }, 404);
    await env.DB.prepare("UPDATE apps SET downloads = downloads + 1 WHERE id = ?").bind(app.id).run();
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set("Content-Type", "application/vnd.android.package-archive");
    headers.set("Content-Disposition", `attachment; filename="${app.id}.apk"`);
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Cache-Control", "public, max-age=3600");
    return new Response(object.body, { headers });
  }

  return json({ error: "API route not found." }, 404);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      try { return await handleApi(request, env, url); }
      catch (error) {
        console.error("API error:", error);
        return json({ error: "Server error. Please try again." }, 500);
      }
    }
    return env.ASSETS.fetch(request);
  }
};